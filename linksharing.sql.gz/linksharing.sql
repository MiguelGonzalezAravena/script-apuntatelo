-- MySQL dump 10.11
--
-- Host: localhost    Database: extreme_linksharing
-- ------------------------------------------------------
-- Server version	5.0.67-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cantidad`
--

DROP TABLE IF EXISTS `cantidad`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cantidad` (
  `id` tinyint(1) NOT NULL auto_increment,
  `cant` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cantidad`
--

LOCK TABLES `cantidad` WRITE;
/*!40000 ALTER TABLE `cantidad` DISABLE KEYS */;
INSERT INTO `cantidad` (`id`, `cant`) VALUES (1,5),(2,2);
/*!40000 ALTER TABLE `cantidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `categorias` (
  `id_categoria` tinyint(3) NOT NULL auto_increment,
  `nom_categoria` varchar(20) default NULL,
  `imagen` varchar(30) default NULL,
  `link_categoria` varchar(30) default NULL,
  PRIMARY KEY  (`id_categoria`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` (`id_categoria`, `nom_categoria`, `imagen`, `link_categoria`) VALUES (1,'Apuntes','Apuntes.png','Apuntes'),(2,'Ebooks','Ebooks.png','Ebooks'),(3,'Ex&aacute;menes','Examenes.png','Examenes'),(4,'Info','Info-Universidades.png','Info-Universidades'),(5,'Soft','Softs-Estudiantiles.png','Softs-Estudiantiles'),(6,'Videos','Videos.png','Videos'),(7,'Biograf&iacute;as','Biografias.png','Biografias'),(8,'Tutoriales','Tutoriales.png','Tutoriales');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comentarios`
--

DROP TABLE IF EXISTS `comentarios`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `comentarios` (
  `id` bigint(7) NOT NULL auto_increment,
  `id_post` bigint(20) NOT NULL default '0',
  `categoria` tinyint(4) NOT NULL default '0',
  `id_autor` bigint(20) NOT NULL default '0',
  `autor` varchar(25) NOT NULL default '',
  `comentario` text NOT NULL,
  `elim` tinyint(4) NOT NULL default '0',
  `id_modera` bigint(20) default NULL,
  `modera` varchar(25) default NULL,
  `causa` varchar(40) NOT NULL default '',
  `fecha` datetime NOT NULL default '0000-00-00 00:00:00',
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `comentarios`
--

LOCK TABLES `comentarios` WRITE;
/*!40000 ALTER TABLE `comentarios` DISABLE KEYS */;
INSERT INTO `comentarios` (`id`, `id_post`, `categoria`, `id_autor`, `autor`, `comentario`, `elim`, `id_modera`, `modera`, `causa`, `fecha`) VALUES (1,1,0,1,'Miguelithox','&iquest;Les gusta el Script?',0,NULL,NULL,'','2009-03-20 18:50:32');
/*!40000 ALTER TABLE `comentarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favoritos`
--

DROP TABLE IF EXISTS `favoritos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `favoritos` (
  `id` bigint(11) NOT NULL auto_increment,
  `id_post` bigint(11) default NULL,
  `id_usuario` bigint(11) default NULL,
  `fecha` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `favoritos`
--

LOCK TABLES `favoritos` WRITE;
/*!40000 ALTER TABLE `favoritos` DISABLE KEYS */;
/*!40000 ALTER TABLE `favoritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensajes`
--

DROP TABLE IF EXISTS `mensajes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mensajes` (
  `id_mensaje` bigint(11) NOT NULL auto_increment,
  `id_emisor` bigint(11) default NULL,
  `id_receptor` bigint(11) default NULL,
  `asunto` varchar(200) collate latin1_general_ci default NULL,
  `contenido` text collate latin1_general_ci,
  `papelera_emisor` tinyint(1) default '0',
  `papelera_receptor` tinyint(1) default '0',
  `eliminado_emisor` tinyint(1) default '0',
  `eliminado_receptor` tinyint(1) default '0',
  `id_carpeta` bigint(11) default '0',
  `leido_emisor` tinyint(1) default '0',
  `leido_receptor` tinyint(1) default '0',
  `fecha` datetime default NULL,
  `fecha_papelera` datetime default NULL,
  PRIMARY KEY  (`id_mensaje`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mensajes`
--

LOCK TABLES `mensajes` WRITE;
/*!40000 ALTER TABLE `mensajes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensajes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `pedidos` (
  `id` bigint(11) NOT NULL auto_increment,
  `id_autor` bigint(11) default NULL,
  `pedido` text collate latin1_general_ci,
  `fecha` datetime default NULL,
  `completo` tinyint(1) default '0',
  `id_post` bigint(11) default NULL,
  `id_comp` bigint(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `posts` (
  `id` bigint(20) NOT NULL auto_increment,
  `elim` tinyint(4) NOT NULL default '0',
  `id_autor` bigint(20) NOT NULL default '0',
  `titulo` varchar(170) NOT NULL default '',
  `contenido` text NOT NULL,
  `fecha` datetime NOT NULL default '0000-00-00 00:00:00',
  `privado` tinyint(4) NOT NULL default '0',
  `coments` tinyint(4) NOT NULL default '0',
  `puntos` bigint(20) NOT NULL default '0',
  `comentarios` int(11) NOT NULL default '0',
  `visitas` bigint(20) NOT NULL default '0',
  `tags` text NOT NULL,
  `categoria` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`id`, `elim`, `id_autor`, `titulo`, `contenido`, `fecha`, `privado`, `coments`, `puntos`, `comentarios`, `visitas`, `tags`, `categoria`) VALUES (1,0,1,'&iquest;C&oacute;mo empezar en eXtreme Zone?','Antes que nada les voy a comentar acerca de qu&eacute; trata eXtreme Zone, la idea es compartir mediante [b]posts[/b] hechos por ustedes mismos las herramientas que les parezcan interesantes a aquellos que siguen una carrera, ya sean apuntes, libros, programas, etc.\r\n\r\n[align=center][b]&iquest;C&oacute;mo hacer un posts?[/b][/align]\r\n\r\nPrimeramente tienes que estar registrado, para eso hace click en [url=/registro/]Registrarse[/url] y completa los datos, luego de completar los datos y aceptar el [url=/protocolo.php]Protocolo[/url], te va a llegar un mail para que confirmes el registro, una vez que estemos registrados, con el usuario y contrase&ntilde;a vamos a poder loguearnos.\r\n\r\nUna vez logueados vamos a [url=/agregar_post/]Agregar[/url], y entramos al editor de post.\r\n\r\n[b]1.[/b] [color=green][b]Titulo[/b][/color]: L&oacute;gicamente ir&iacute;a el T&iacute;tulo del post.\r\n\r\n[b]2.[/b] [color=green][b]Barra de Personalizaci&oacute;n de texto.[/b][/color]\r\n[img]/imagenes/tutorial/1.png[/img]\r\n\r\n[b]2.1[/b] Texto alineado hacia la Izquierda\r\n[b]2.2[/b] Texto centrado\r\n[b]2.3 [/b]Texto alineado hacia la Derecha\r\n[b]2.4[/b] Texto en [b]Negrita[/b]\r\n[b]2.5[/b] Texto en [i]Cursiva[/i]\r\n[b]2.6[/b] Texto con [u]Subrayado[/u]\r\n[b]2.7 [/b]Texto Coloreado\r\n[b]2.8[/b] Texto con Tama&ntilde;o\r\n[b]2.9[/b] Introducir un Video de Youtube\r\n[img]/imagenes/tutorial/2.PNG[/img]\r\n[swf=http://www.youtube.com/v/8GouKe4Osc8]\r\n[b]2.10[/b] Introducir una Imagen\r\n[img]/imagenes/tutorial/3.PNG[/img]\r\n[b]2.11[/b] Introducir un Enlace\r\n[img]/imagenes/tutorial/4.PNG[/img]\r\n[url=/]eXtreme Zone[/url]\r\n\r\n[b]3.[/b] [b][color=green]Lista de Iconos[/color][/b]\r\n[img]/imagenes/tutorial/5.PNG[/img]\r\n\r\nPara usarlos, debes hacer click encima del Icono que quieras. Si quieres ver m&aacute;s haz click en &quot;M&aacute;s&quot;.\r\n\r\n[b]4.[/b] [b][color=green]Categor&iacute;as[/color][/b]\r\n[img]/imagenes/tutorial/6.PNG[/img]\r\n\r\nElige la categor&iacute;a correspondiente para tu posts.\r\n\r\n[b]5.[/b] [b][color=green]Tags[/color][/b]\r\n[img]/imagenes/tutorial/7.PNG[/img]\r\n\r\nEscribe 3 tags o m&aacute;s que represente a tu Post, separado por coma\r\nEjemplo: eXtreme, Zone, Comunidad, Linksharing\r\n\r\n[b]6.[/b] [b][color=green]Opciones[/color][/b]\r\n[img]/imagenes/tutorial/8.PNG[/img]\r\n\r\nSi seleccionas la casilla [b]Privado[/b], tu post solamente lo podr&aacute;n ver usuarios registrados.\r\nSi seleccionas la casilla [b]Cerrar los comentarios[/b], tu post no podr&aacute; tener comentarios.\r\n[b]\r\nEspero que les haya gustado este tutorial.\r\nSaludos.[/b]','2009-03-13 19:50:56',0,0,0,5,156,'Empezar, eXtreme, Zone, Novato',4);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_eliminados`
--

DROP TABLE IF EXISTS `posts_eliminados`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `posts_eliminados` (
  `Id` int(11) NOT NULL auto_increment,
  `id_modera` int(11) default NULL,
  `id_post` int(11) default NULL,
  `causa` varchar(210) default NULL,
  `fecha` datetime default NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `posts_eliminados`
--

LOCK TABLES `posts_eliminados` WRITE;
/*!40000 ALTER TABLE `posts_eliminados` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_eliminados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `puntos`
--

DROP TABLE IF EXISTS `puntos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `puntos` (
  `num` bigint(20) NOT NULL default '0',
  `id_punteador` bigint(20) NOT NULL default '0',
  `puntos` bigint(20) NOT NULL default '0',
  `fecha` datetime default '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `puntos`
--

LOCK TABLES `puntos` WRITE;
/*!40000 ALTER TABLE `puntos` DISABLE KEYS */;
/*!40000 ALTER TABLE `puntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stickies`
--

DROP TABLE IF EXISTS `stickies`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stickies` (
  `id` bigint(20) NOT NULL auto_increment,
  `orden` smallint(2) default NULL,
  `id_post` bigint(20) NOT NULL default '0',
  `elim` tinyint(4) NOT NULL default '0',
  `creador` varchar(25) default NULL,
  `modera` varchar(25) default NULL,
  `fecha` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stickies`
--

LOCK TABLES `stickies` WRITE;
/*!40000 ALTER TABLE `stickies` DISABLE KEYS */;
INSERT INTO `stickies` (`id`, `orden`, `id_post`, `elim`, `creador`, `modera`, `fecha`) VALUES (1,1,1,0,'Miguelithox',NULL,'2009-03-15 19:29:44');
/*!40000 ALTER TABLE `stickies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suspendidos`
--

DROP TABLE IF EXISTS `suspendidos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `suspendidos` (
  `id` bigint(20) NOT NULL auto_increment,
  `nick` varchar(20) NOT NULL default '',
  `modera` varchar(20) default NULL,
  `activa` varchar(20) default NULL,
  `causa` text NOT NULL,
  `fecha1` datetime NOT NULL default '0000-00-00 00:00:00',
  `fecha2` datetime NOT NULL default '0000-00-00 00:00:00',
  `activo` int(11) NOT NULL default '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `suspendidos`
--

LOCK TABLES `suspendidos` WRITE;
/*!40000 ALTER TABLE `suspendidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `suspendidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `usuarios` (
  `id` bigint(20) NOT NULL auto_increment,
  `id_extreme` varchar(40) NOT NULL default '',
  `activacion` tinyint(4) NOT NULL default '0',
  `ban` tinyint(4) NOT NULL default '0',
  `rango` varchar(25) NOT NULL default '',
  `nombre` varchar(40) NOT NULL default '',
  `nick` varchar(25) NOT NULL default '',
  `password` varchar(40) NOT NULL default '',
  `puntos` bigint(20) NOT NULL default '0',
  `puntosdar` smallint(6) NOT NULL default '0',
  `mail` varchar(45) NOT NULL default '',
  `avatar` varchar(160) NOT NULL default '',
  `pais` tinytext NOT NULL,
  `ciudad` varchar(55) NOT NULL default '0',
  `sexo` tinytext NOT NULL,
  `dia` tinyint(4) NOT NULL default '0',
  `mes` tinyint(4) NOT NULL default '0',
  `ano` smallint(6) NOT NULL default '0',
  `mensajero` varchar(45) default NULL,
  `mensaje` varchar(110) default NULL,
  `fecha` datetime NOT NULL default '0000-00-00 00:00:00',
  `numposts` bigint(20) NOT NULL default '0',
  `numcomentarios` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`id`, `id_extreme`, `activacion`, `ban`, `rango`, `nombre`, `nick`, `password`, `puntos`, `puntosdar`, `mail`, `avatar`, `pais`, `ciudad`, `sexo`, `dia`, `mes`, `ano`, `mensajero`, `mensaje`, `fecha`, `numposts`, `numcomentarios`) VALUES (1,'b3dc36c964199e9b7a56c6a72b01fa78',1,0,'Administrador','Miguel Gonz&aacute;lez','Miguelithox','e10adc3949ba59abbe56e057f20f883e',0,30,'miguel.gonzalez.93@gmail.com','http://127.0.0.1/imagenes/smileys/icon_cheesygrin.gif','cl','Vi&ntilde;a Del Mar','m',15,11,1993,'miguelithox@extreme-zone.cl','Bienvenido','2009-03-08 18:56:50',1,1),(2,'ad3aceb43a845a2a017009a50a5bbee5',0,0,'Usuario Full','Phobos91','Phobos91','bf420da5d1694c57a5e30eaf34ffe1e8',0,0,'phobos91s@gmail.com','http://www.extreme-zone.cl/imagenes/avatar.jpg','ar','Buenos Aires','m',17,8,1991,'','You Know You\'re Right','2009-03-16 00:40:48',0,0),(3,'3c77fae8a0f8dc6f30c47c3cb3b2566d',0,0,'Usuario Full','sasasa','trombonete','453e41d218e071ccfb2d1c99ce23906a',0,0,'tromboneteenojado@live.com.ar','http://www.extreme-zone.cl/imagenes/avatar.jpg','ar','ssss','m',1,2,1977,'msn','hola','2009-03-16 12:20:13',0,0),(4,'31e6db42f8bde3cc0e149b75f5ab5288',0,0,'Usuario Full','Vicente Villalba','vicent48','844e6b41b9c581f63d4a4215ca45ea87',0,0,'acela798@hotmail.com','http://www.extreme-zone.cl/imagenes/avatar.jpg','ar','Buenos Aires','m',0,0,0,'','','2009-03-17 18:52:41',0,0),(5,'89edb19b57b18670525149ca9d07c803',0,0,'Usuario Full','juegosm','juegosmuchoslink','1f216b775393762344057b65928b34a4',0,0,'juegosmuchoslink2@gmail.com','http://www.extreme-zone.cl/imagenes/avatar.jpg','ar','buenos aires','m',16,11,1989,'gmail','http://www.juimpi.com.ar','2009-03-17 19:14:38',0,0),(6,'77887dcd6e091bcc7d24cda1ac845fe7',0,0,'Usuario Full','wawawa','prueba','e10adc3949ba59abbe56e057f20f883e',0,0,'crashoverider_666@hotmail.com','http://www.extreme-zone.cl/imagenes/avatar.jpg','ar','capital','',12,12,1985,'','','2009-03-20 20:21:06',0,0),(7,'beb24f576ebc113c7dbcda19b8d99bd2',0,0,'Usuario Full','perejil','perejil','d40b441ba738aaa4fe958769e6c7d1de',0,0,'notengo@mail.com','http://www.extreme-zone.cl/imagenes/avatar.jpg','ar','Magia','m',22,12,1970,'','','2009-03-20 21:59:52',0,0),(8,'257667b478546daa01d33ad9cbd04126',0,0,'Usuario Full','paz','perejil2','d40b441ba738aaa4fe958769e6c7d1de',0,0,'eldepijagrande@yahoo.com.ar','http://www.extreme-zone.cl/imagenes/avatar.jpg','-1','magia','m',22,12,1970,'','','2009-03-20 22:01:51',0,0),(9,'206f6fe25f0924b0fa6aa9404aeb14a4',0,0,'Usuario Full','federico ozan','leandro94','9e376eff2d459d49d5c9185fff6987a5',0,0,'fede.tdf@hotmail.com','http://www.extreme-zone.cl/imagenes/avatar.jpg','ar','Tierra Del Fuego','m',10,8,1993,'','','2009-03-20 23:30:31',0,0),(10,'a16a6ba75044591adf98c536c56514c6',0,0,'Usuario Full','federico ozan','faxred','9e376eff2d459d49d5c9185fff6987a5',0,0,'raul.tdf@gmail.com','http://www.extreme-zone.cl/imagenes/avatar.jpg','ar','Tierra Del Fuego','m',1,8,1993,'','','2009-03-20 23:41:19',0,0);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitas`
--

DROP TABLE IF EXISTS `visitas`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `visitas` (
  `id_post` bigint(11) NOT NULL auto_increment,
  `ip` varchar(20) default NULL,
  `fecha` datetime default NULL,
  PRIMARY KEY  (`id_post`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `visitas`
--

LOCK TABLES `visitas` WRITE;
/*!40000 ALTER TABLE `visitas` DISABLE KEYS */;
INSERT INTO `visitas` (`id_post`, `ip`, `fecha`) VALUES (1,'201.241.113.40','2009-03-15 19:14:33');
/*!40000 ALTER TABLE `visitas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-03-21 22:20:32
